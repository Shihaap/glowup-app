import { useState, useEffect } from "react";

// Safe Capacitor imports - works in browser too
let Preferences = null;
let StatusBar = null;
let SplashScreen = null;
let Style = null;

const initCapacitor = async () => {
  try {
    const cap = await import("@capacitor/core");
    if (cap.Capacitor && cap.Capacitor.isNativePlatform()) {
      const prefMod = await import("@capacitor/preferences");
      Preferences = prefMod.Preferences;
      const sbMod = await import("@capacitor/status-bar");
      StatusBar = sbMod.StatusBar;
      Style = sbMod.Style;
      const ssMod = await import("@capacitor/splash-screen");
      SplashScreen = ssMod.SplashScreen;
      if (StatusBar) await StatusBar.setStyle({ style: Style.Dark });
      if (StatusBar) await StatusBar.setBackgroundColor({ color: "#080808" });
      if (SplashScreen) await SplashScreen.hide();
    }
  } catch (_) {}
};

// Storage — uses Capacitor Preferences on Android, localStorage in browser
const Store = {
  async get(key) {
    try {
      if (Preferences) {
        const { value } = await Preferences.get({ key });
        return value ? JSON.parse(value) : null;
      }
      const v = localStorage.getItem(key);
      return v ? JSON.parse(v) : null;
    } catch { return null; }
  },
  async set(key, val) {
    try {
      if (Preferences) {
        await Preferences.set({ key, value: JSON.stringify(val) });
      } else {
        localStorage.setItem(key, JSON.stringify(val));
      }
    } catch {}
  },
};

// ── CSS ──────────────────────────────────────────────────────────────────────
const CSS = `
  :root {
    --bg:#080808;--sf:#111;--sf2:#1a1a1a;
    --lime:#C8FF00;--pink:#FF3366;--cyan:#00EFFF;--ora:#FF7A00;
    --wh:#F0F0F0;--mu:#666;--bd:#222;--bd2:#2a2a2a;
    --fd:'Bebas Neue',sans-serif;--fb:'DM Sans',sans-serif;--fm:'Space Mono',monospace;
    --r:20px;--rs:12px;
    --sab:env(safe-area-inset-bottom,0px);
  }
  *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
  html,body,#root{height:100%;}
  body{background:var(--bg);color:var(--wh);font-family:var(--fb);overscroll-behavior:none;-webkit-tap-highlight-color:transparent;-webkit-font-smoothing:antialiased;user-select:none;}
  ::-webkit-scrollbar{display:none;}
  @keyframes sup{from{opacity:0;transform:translateY(26px)}to{opacity:1;transform:translateY(0)}}
  @keyframes tkr{0%{transform:translateX(110%)}100%{transform:translateX(-100%)}}
  @keyframes pls{0%,100%{opacity:1}50%{opacity:0.4}}
  .sup{animation:sup .45s cubic-bezier(.22,1,.36,1) both;}
  .tkr{display:inline-block;white-space:nowrap;animation:tkr 22s linear infinite;}
  .dot{width:7px;height:7px;border-radius:50%;background:var(--lime);display:inline-block;animation:pls 2s ease-in-out infinite;}
  .nb{border:none;background:transparent;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:3px;padding:10px 14px;border-radius:var(--rs);color:var(--mu);font-family:var(--fb);font-size:10px;font-weight:600;letter-spacing:.3px;transition:color .2s;-webkit-tap-highlight-color:transparent;}
  .nb.on{color:var(--lime);}
  .card{background:var(--sf);border:1px solid var(--bd);border-radius:var(--r);padding:20px;}
  .pill{display:inline-flex;align-items:center;gap:5px;background:var(--sf2);border-radius:999px;padding:5px 12px;font-size:11px;font-weight:600;}
  .blime{background:var(--lime);color:#000;border:none;border-radius:var(--rs);padding:16px;font-family:var(--fb);font-weight:700;font-size:15px;cursor:pointer;width:100%;transition:transform .15s,opacity .15s;}
  .blime:active{transform:scale(.97);}
  .blime:disabled{opacity:.3;}
  .bghost{background:transparent;color:var(--mu);border:1.5px solid var(--bd);border-radius:var(--rs);padding:10px 18px;font-family:var(--fb);font-size:13px;font-weight:500;cursor:pointer;transition:all .2s;}
  .bghost:hover{border-color:var(--wh);color:var(--wh);}
  .ci{transition:transform .15s;cursor:pointer;-webkit-tap-highlight-color:transparent;}
  .ci:active{transform:scale(.97);}
  input[type=range]{-webkit-appearance:none;appearance:none;background:transparent;cursor:pointer;width:100%;}
  input[type=range]::-webkit-slider-runnable-track{background:#1e1e1e;height:6px;border-radius:3px;}
  input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:24px;height:24px;border-radius:50%;background:var(--lime);margin-top:-9px;box-shadow:0 0 12px rgba(200,255,0,.4);}
`;

// ── DATA ─────────────────────────────────────────────────────────────────────
const QUOTES = [
  {t:"You don't need a gym. You need a decision.",a:"— No excuses"},
  {t:"Your only competition is who you were yesterday.",a:"— Hostel Room Rules"},
  {t:"Discipline is choosing what you want most over what you want now.",a:"— Anonymous"},
  {t:"Glow up isn't a moment. It's a daily decision.",a:"— The mirror"},
  {t:"Your body hears everything your mind says.",a:"— You, 90 days from now"},
  {t:"Small daily improvements are the key to staggering long-term results.",a:"— James Clear"},
  {t:"The best project you'll ever work on is yourself.",a:"— Always"},
  {t:"One workout away from a good mood.",a:"— Science, basically"},
];

const WORKOUTS = [
  {id:"w1",name:"Morning Ignition",emoji:"🌅",tag:"Full Body",dur:"15 min",lvl:"Beginner",ex:[
    {n:"Jumping Jacks",s:"3",r:"30 sec",tip:"Get heart rate up first!"},
    {n:"Push-Ups",s:"3",r:"10",tip:"Keep core tight, chest to floor."},
    {n:"Bodyweight Squats",s:"3",r:"15",tip:"Knees behind toes, go deep."},
    {n:"Plank Hold",s:"3",r:"30 sec",tip:"Squeeze glutes and breathe."},
    {n:"Mountain Climbers",s:"2",r:"20 sec",tip:"Drive knees fast!"},
  ]},
  {id:"w2",name:"Hostel Shred",emoji:"🔥",tag:"HIIT",dur:"20 min",lvl:"Intermediate",ex:[
    {n:"Burpees",s:"4",r:"8",tip:"Explode up on every rep!"},
    {n:"Pike Push-Ups",s:"3",r:"10",tip:"Great for shoulders, no gym."},
    {n:"Reverse Lunges",s:"3",r:"12 each",tip:"Step back, not forward."},
    {n:"High Knees",s:"3",r:"40 sec",tip:"Pump your arms hard!"},
    {n:"Tricep Dips (Chair)",s:"3",r:"12",tip:"Use your hostel chair edge."},
    {n:"Leg Raises",s:"3",r:"15",tip:"Lower back stays flat."},
  ]},
  {id:"w3",name:"Core Destroyer",emoji:"⚡",tag:"Core",dur:"12 min",lvl:"Any",ex:[
    {n:"Crunches",s:"3",r:"20",tip:"Exhale at top, slow it down."},
    {n:"Bicycle Crunches",s:"3",r:"16 each",tip:"Slow = more burn."},
    {n:"Russian Twists",s:"3",r:"20",tip:"Heels off floor for extra burn."},
    {n:"Flutter Kicks",s:"3",r:"30 sec",tip:"Small fast kicks, back flat."},
    {n:"Plank",s:"3",r:"30 sec",tip:"Don't let your hips sag!"},
  ]},
  {id:"w4",name:"Posture King",emoji:"👑",tag:"Posture",dur:"10 min",lvl:"Beginner",ex:[
    {n:"Cat-Cow Stretch",s:"2",r:"10",tip:"Move with your breath."},
    {n:"Superman Hold",s:"3",r:"12",tip:"Squeeze back muscles hard."},
    {n:"Wall Angels",s:"3",r:"10",tip:"Entire back touching wall."},
    {n:"Chin Tucks",s:"3",r:"15",tip:"Fix forward head posture."},
    {n:"Hip Flexor Stretch",s:"2",r:"30 sec each",tip:"Hostel chairs ruin your hips!"},
  ]},
  {id:"w5",name:"Night Burner",emoji:"🌙",tag:"Low Impact",dur:"15 min",lvl:"Beginner",ex:[
    {n:"Slow Squats",s:"3",r:"15",tip:"3 seconds down, 3 up."},
    {n:"Glute Bridges",s:"3",r:"15",tip:"Squeeze hard at the top!"},
    {n:"Calf Raises",s:"3",r:"25",tip:"Hold top for 1 second."},
    {n:"Wall Sit",s:"3",r:"40 sec",tip:"Back flat, thighs parallel."},
    {n:"Child's Pose",s:"1",r:"2 min",tip:"Recover and reset."},
  ]},
];

const SKIN = [
  {id:"s1",e:"💧",t:"Drink 2L Water",d:"Clearest free skin hack. Flush toxins, hydrate from inside.",tag:"AM+PM"},
  {id:"s2",e:"🌊",t:"Cold Water Face Wash",d:"Morning & night. Removes oil without stripping skin.",tag:"AM+PM"},
  {id:"s3",e:"🧴",t:"Moisturize (Coconut Oil)",d:"Tiny bit after washing. Locks in hydration.",tag:"Night"},
  {id:"s4",e:"🧊",t:"Ice Cube Massage",d:"1 min on face. Shrinks pores, kills puffiness. Free facial!",tag:"AM"},
  {id:"s5",e:"😴",t:"Sleep 7–8 Hours",d:"Skin repairs at night. No product beats sleep.",tag:"Night"},
  {id:"s6",e:"🚫",t:"Stop Touching Your Face",d:"Hands carry bacteria. Every touch = potential breakout.",tag:"All day"},
  {id:"s7",e:"🍋",t:"Lemon + Honey Spot Treat",d:"Dab on pimples at night. Natural and effective.",tag:"Night"},
  {id:"s8",e:"🌿",t:"Aloe Vera",d:"Break a leaf, apply directly. Soothes and heals redness.",tag:"Anytime"},
  {id:"s9",e:"🧘",t:"5-Min Deep Breathing",d:"Stress = cortisol = breakouts. Breathe to reset.",tag:"Daily"},
  {id:"s10",e:"☀️",t:"Protect From Sun",d:"Cap, scarf, or dupatta. UV damage is permanent.",tag:"Outdoors"},
];

const TIPS = ["✦ No gym — bodyweight IS the gym","✦ Drink water before meals — eat 15% less","✦ Walk everywhere on campus","✦ Sleep = free fat burner","✦ Posture = instant confidence","✦ Cold water beats any expensive face wash","✦ 10 push-ups every morning changes everything"];
const LVL = {Beginner:"#00EFFF",Intermediate:"#FF7A00",Any:"#C8FF00"};
const todayStr = () => new Date().toDateString();

// ── RING ─────────────────────────────────────────────────────────────────────
function Ring({pct,size=86,stroke=8,color="#C8FF00",children}){
  const r=(size-stroke)/2, circ=2*Math.PI*r, off=circ-(pct/100)*circ;
  return (
    <svg width={size} height={size} style={{display:"block"}}>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="#1e1e1e" strokeWidth={stroke}/>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={stroke}
        strokeLinecap="round" strokeDasharray={circ} strokeDashoffset={off}
        transform={`rotate(-90 ${size/2} ${size/2})`}
        style={{transition:"stroke-dashoffset 1s cubic-bezier(.22,1,.36,1)"}}/>
      <foreignObject x={0} y={0} width={size} height={size}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"center",height:"100%",flexDirection:"column"}}>{children}</div>
      </foreignObject>
    </svg>
  );
}

// ── HOME ─────────────────────────────────────────────────────────────────────
function HomeTab({tracker,streak}){
  const [qi,setQi]=useState(0);
  const q=QUOTES[qi];
  const now=new Date();
  const day=now.toLocaleDateString("en-US",{weekday:"long"});
  const date=now.toLocaleDateString("en-US",{month:"long",day:"numeric"});
  return (
    <div className="sup" style={{display:"flex",flexDirection:"column",gap:14}}>
      {/* Hero */}
      <div style={{background:"linear-gradient(135deg,#0e0e0e,#141414)",border:"1px solid #1f1f1f",borderRadius:"var(--r)",padding:"26px 22px",position:"relative",overflow:"hidden"}}>
        <div style={{position:"absolute",top:-50,right:-50,width:180,height:180,background:"radial-gradient(circle,rgba(200,255,0,0.07) 0%,transparent 70%)",borderRadius:"50%",pointerEvents:"none"}}/>
        <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:14}}>
          <span className="dot"/>
          <span style={{fontFamily:"var(--fm)",fontSize:11,color:"var(--mu)",letterSpacing:".5px"}}>{day} · {date}</span>
        </div>
        <h1 style={{fontFamily:"var(--fd)",fontSize:50,lineHeight:.92,letterSpacing:"2px",marginBottom:10}}>
          TIME TO<br/><span style={{color:"var(--lime)"}}>GLOW UP.</span>
        </h1>
        <p style={{color:"var(--mu)",fontSize:13,lineHeight:1.5}}>Hostel life won't stop your transformation. 💪<br/>
          <span style={{color:"#444",fontSize:12}}>No gym. No money. Just discipline.</span></p>
      </div>

      {/* Quote */}
      <div onClick={()=>setQi((qi+1)%QUOTES.length)}
        style={{background:"linear-gradient(135deg,#1a0010,#0f0008)",border:"1.5px solid rgba(255,51,102,.2)",borderRadius:"var(--r)",padding:"20px 22px",position:"relative",overflow:"hidden"}}>
        <div style={{position:"absolute",top:-15,right:-10,fontSize:70,opacity:.08}}>💬</div>
        <p style={{fontSize:15,fontWeight:500,lineHeight:1.55,color:"#e8e8e8",marginBottom:8}}>"{q.t}"</p>
        <p style={{fontSize:11,color:"var(--pink)",fontStyle:"italic"}}>{q.a}</p>
        <p style={{fontSize:10,color:"#333",marginTop:8}}>tap for next →</p>
      </div>

      {/* Stats */}
      <div className="card">
        <p style={{fontFamily:"var(--fd)",fontSize:16,letterSpacing:"1.5px",color:"var(--mu)",marginBottom:18}}>TODAY'S SNAPSHOT</p>
        <div style={{display:"flex",justifyContent:"space-around"}}>
          {[{l:"Water",v:tracker.water,m:8,u:"gl",c:"#00EFFF"},{l:"Steps",v:tracker.steps,m:10000,u:"k",c:"#C8FF00"},{l:"Sleep",v:tracker.sleep,m:8,u:"h",c:"#FF7A00"}].map(s=>(
            <div key={s.l} style={{display:"flex",flexDirection:"column",alignItems:"center",gap:8}}>
              <Ring pct={Math.min(100,Math.round((s.v/s.m)*100))} color={s.c}>
                <span style={{fontFamily:"var(--fd)",fontSize:18,color:s.c,lineHeight:1}}>{s.v}</span>
                <span style={{fontSize:9,color:"var(--mu)"}}>{s.u}</span>
              </Ring>
              <span style={{fontSize:10,color:"var(--mu)",fontWeight:600,textTransform:"uppercase",letterSpacing:".5px"}}>{s.l}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Streak */}
      <div style={{background:"var(--sf)",border:"1px solid #1f1f1f",borderRadius:"var(--r)",padding:"18px 20px",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
        <div>
          <p style={{fontFamily:"var(--fd)",fontSize:52,lineHeight:1,color:"var(--ora)"}}>{streak}</p>
          <p style={{color:"var(--mu)",fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:"1px",marginTop:2}}>Day Streak 🔥</p>
        </div>
        <div style={{textAlign:"right",maxWidth:150}}>
          <p style={{fontSize:13,fontWeight:600,lineHeight:1.4}}>Keep showing up.</p>
          <p style={{color:"var(--mu)",fontSize:12,marginTop:4}}>Even 10 mins counts.</p>
        </div>
      </div>

      {/* Ticker */}
      <div style={{background:"var(--lime)",borderRadius:"var(--rs)",padding:"11px 0",overflow:"hidden"}}>
        <div className="tkr" style={{color:"#000",fontFamily:"var(--fd)",fontSize:15,letterSpacing:"2px"}}>{TIPS.join("    ·    ")}</div>
      </div>

      {/* Confidence */}
      <div style={{background:"#0a0a0a",border:"1px solid #1a1a1a",borderRadius:"var(--r)",padding:"18px 20px"}}>
        <p style={{fontFamily:"var(--fd)",fontSize:20,color:"var(--cyan)",marginBottom:12,letterSpacing:"1px"}}>⚡ INSTANT CONFIDENCE</p>
        {["Stand straight → posture adds 10x confidence.","Slow movements — slow = in control.","Make eye contact. Ultimate confidence signal.","Walk like you own the hallway. Head up."].map((t,i)=>(
          <div key={i} style={{display:"flex",gap:10,marginBottom:8,alignItems:"flex-start"}}>
            <span style={{color:"var(--cyan)",fontFamily:"var(--fm)",fontSize:11,flexShrink:0}}>0{i+1}</span>
            <p style={{color:"#999",fontSize:13,lineHeight:1.5}}>{t}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── WORKOUT ───────────────────────────────────────────────────────────────────
function WorkoutTab({onComplete}){
  const [sel,setSel]=useState(null);
  const [done,setDone]=useState({});
  const [compl,setCompl]=useState([]);
  const toggle=i=>setDone(d=>({...d,[i]:!d[i]}));
  const dc=Object.values(done).filter(Boolean).length;

  const finish=()=>{
    onComplete(sel.name);
    setCompl(c=>[...c,sel.id]);
    setSel(null);setDone({});
  };

  if(sel){
    const pct=Math.round((dc/sel.ex.length)*100);
    return (
      <div className="sup" style={{display:"flex",flexDirection:"column",gap:12}}>
        <button className="bghost" onClick={()=>{setSel(null);setDone({});}} style={{alignSelf:"flex-start"}}>← Back</button>
        <div style={{display:"flex",gap:14,alignItems:"center"}}>
          <span style={{fontSize:44,lineHeight:1}}>{sel.emoji}</span>
          <div>
            <h2 style={{fontFamily:"var(--fd)",fontSize:30,lineHeight:1.1,letterSpacing:"1px"}}>{sel.name}</h2>
            <div style={{display:"flex",gap:8,marginTop:6}}>
              <span className="pill" style={{color:LVL[sel.lvl],fontSize:10}}>{sel.lvl}</span>
              <span className="pill" style={{fontSize:10}}>⏱ {sel.dur}</span>
            </div>
          </div>
        </div>
        <div className="card" style={{padding:16}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:10}}>
            <span style={{fontSize:12,color:"var(--mu)",fontWeight:700,textTransform:"uppercase",letterSpacing:"1px"}}>Progress</span>
            <span style={{fontFamily:"var(--fd)",fontSize:22,color:"var(--lime)"}}>{pct}%</span>
          </div>
          <div style={{height:6,background:"#1e1e1e",borderRadius:3,overflow:"hidden"}}>
            <div style={{height:"100%",width:`${pct}%`,background:"var(--lime)",borderRadius:3,transition:"width .5s"}}/>
          </div>
        </div>
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          {sel.ex.map((ex,i)=>(
            <div key={i} className="ci" onClick={()=>toggle(i)}
              style={{background:done[i]?"rgba(200,255,0,.06)":"var(--sf)",border:done[i]?"1.5px solid rgba(200,255,0,.25)":"1px solid var(--bd)",borderRadius:"var(--rs)",padding:"16px",display:"flex",gap:14,alignItems:"flex-start"}}>
              <div style={{width:26,height:26,borderRadius:"50%",border:done[i]?"none":"2px solid #333",background:done[i]?"var(--lime)":"transparent",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,marginTop:2,transition:"all .2s"}}>
                {done[i]&&<span style={{color:"#000",fontSize:14,fontWeight:800}}>✓</span>}
              </div>
              <div style={{flex:1}}>
                <p style={{fontWeight:600,fontSize:14,color:done[i]?"var(--lime)":"var(--wh)",textDecoration:done[i]?"line-through":"none",opacity:done[i]?.7:1}}>{ex.n}</p>
                <p style={{color:"var(--mu)",fontSize:12,marginTop:2}}>{ex.s} sets · {ex.r}</p>
                <p style={{color:"#3a3a3a",fontSize:11,marginTop:4,fontStyle:"italic"}}>💡 {ex.tip}</p>
              </div>
            </div>
          ))}
        </div>
        <button className="blime" onClick={finish} disabled={dc===0}>
          {pct===100?"🔥 Completed! Mark as Done":`Done ${dc}/${sel.ex.length} · Mark Complete`}
        </button>
      </div>
    );
  }

  return (
    <div className="sup" style={{display:"flex",flexDirection:"column",gap:14}}>
      <div>
        <h2 style={{fontFamily:"var(--fd)",fontSize:42,lineHeight:.95,letterSpacing:"2px"}}>HOSTEL<br/><span style={{color:"var(--lime)"}}>WORKOUTS</span></h2>
        <p style={{color:"var(--mu)",fontSize:13,marginTop:6}}>No gym. No equipment. Just you and the floor. 🔥</p>
      </div>
      {WORKOUTS.map(w=>{
        const done=compl.includes(w.id);
        return (
          <div key={w.id} className={done?"":"ci"} onClick={()=>!done&&setSel(w)}
            style={{background:done?"rgba(200,255,0,.04)":"var(--sf)",border:done?"1.5px solid rgba(200,255,0,.2)":"1px solid var(--bd)",borderRadius:"var(--r)",padding:"18px 20px",position:"relative",overflow:"hidden"}}>
            {done&&<div style={{position:"absolute",top:14,right:14,background:"var(--lime)",color:"#000",fontSize:10,fontWeight:800,padding:"3px 10px",borderRadius:999}}>DONE ✓</div>}
            <div style={{display:"flex",gap:14,alignItems:"center"}}>
              <span style={{fontSize:38,lineHeight:1}}>{w.emoji}</span>
              <div style={{flex:1}}>
                <p style={{fontFamily:"var(--fd)",fontSize:24,letterSpacing:".5px",color:done?"var(--lime)":"var(--wh)"}}>{w.name}</p>
                <div style={{display:"flex",gap:8,marginTop:6,flexWrap:"wrap"}}>
                  <span className="pill" style={{color:LVL[w.lvl],fontSize:10}}>{w.lvl}</span>
                  <span className="pill" style={{fontSize:10}}>⏱ {w.dur}</span>
                  <span className="pill" style={{fontSize:10}}>#{w.tag}</span>
                </div>
              </div>
            </div>
            <p style={{color:"var(--mu)",fontSize:12,marginTop:10}}>{w.ex.length} exercises · {done?"Completed today 🏆":"Tap to begin →"}</p>
          </div>
        );
      })}
    </div>
  );
}

// ── SKINCARE ──────────────────────────────────────────────────────────────────
function SkinTab({checked,setChecked}){
  const toggle=id=>setChecked(c=>c.includes(id)?c.filter(x=>x!==id):[...c,id]);
  const pct=Math.round((checked.length/SKIN.length)*100);
  return (
    <div className="sup" style={{display:"flex",flexDirection:"column",gap:14}}>
      <div>
        <h2 style={{fontFamily:"var(--fd)",fontSize:42,lineHeight:.95,letterSpacing:"2px"}}>FREE<br/><span style={{color:"var(--cyan)"}}>SKINCARE</span></h2>
        <p style={{color:"var(--mu)",fontSize:13,marginTop:6}}>Zero rupees. Maximum glow. ✨</p>
      </div>
      <div className="card" style={{padding:16}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
          <span style={{fontSize:12,color:"var(--mu)",fontWeight:700,letterSpacing:"1px",textTransform:"uppercase"}}>Today's Routine</span>
          <span style={{fontFamily:"var(--fd)",fontSize:24,color:"var(--cyan)"}}>{pct}%</span>
        </div>
        <div style={{height:6,background:"#1e1e1e",borderRadius:3,overflow:"hidden",marginBottom:8}}>
          <div style={{height:"100%",width:`${pct}%`,background:"linear-gradient(90deg,#00EFFF,#C8FF00)",borderRadius:3,transition:"width .5s"}}/>
        </div>
        <p style={{color:"#333",fontSize:11}}>{checked.length}/{SKIN.length} done · {pct===100?"🌟 Perfect day!":"Keep going!"}</p>
      </div>
      {SKIN.map(item=>{
        const done=checked.includes(item.id);
        return (
          <div key={item.id} className="ci" onClick={()=>toggle(item.id)}
            style={{background:done?"rgba(0,239,255,.05)":"var(--sf)",border:done?"1.5px solid rgba(0,239,255,.25)":"1px solid var(--bd)",borderRadius:"var(--rs)",padding:"16px",display:"flex",gap:14,alignItems:"flex-start"}}>
            <span style={{fontSize:28,lineHeight:1,flexShrink:0,marginTop:2}}>{item.e}</span>
            <div style={{flex:1}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:8}}>
                <p style={{fontWeight:600,fontSize:14,color:done?"var(--cyan)":"var(--wh)"}}>{item.t}</p>
                <span style={{fontSize:9,color:"var(--mu)",background:"var(--sf2)",padding:"2px 8px",borderRadius:999,flexShrink:0}}>{item.tag}</span>
              </div>
              <p style={{color:"var(--mu)",fontSize:12,marginTop:5,lineHeight:1.55}}>{item.d}</p>
              {done&&<p style={{color:"var(--cyan)",fontSize:11,marginTop:6,fontWeight:700}}>✓ Done! Glowing up.</p>}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ── TRACK ─────────────────────────────────────────────────────────────────────
function TrackTab({tracker,setTracker}){
  const upd=(k,v)=>setTracker(t=>({...t,[k]:v}));
  const rows=[
    {k:"water",l:"Water Intake",e:"💧",u:"glasses",m:10,c:"#00EFFF",tip:"Goal: 8 glasses daily."},
    {k:"steps",l:"Steps Walked",e:"👟",u:"steps",m:15000,c:"#C8FF00",tip:"Aim for 8,000+. Walk to class!"},
    {k:"sleep",l:"Sleep Hours",e:"😴",u:"hours",m:10,c:"#FF7A00",tip:"7–8 hours is golden."},
    {k:"calories",l:"Meals Today",e:"🍱",u:"meals",m:5,c:"#FF3366",tip:"3–4 balanced meals."},
  ];
  return (
    <div className="sup" style={{display:"flex",flexDirection:"column",gap:14}}>
      <div>
        <h2 style={{fontFamily:"var(--fd)",fontSize:42,lineHeight:.95,letterSpacing:"2px"}}>DAILY<br/><span style={{color:"var(--ora)"}}>TRACKER</span></h2>
        <p style={{color:"var(--mu)",fontSize:13,marginTop:6}}>Track it. Watch yourself level up. 📈</p>
      </div>
      {rows.map(({k,l,e,u,m,c,tip})=>{
        const val=tracker[k]||0;
        const pct=Math.min(100,Math.round((val/m)*100));
        return (
          <div key={k} className="card" style={{padding:"20px"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:14}}>
              <div style={{display:"flex",gap:12,alignItems:"center"}}>
                <span style={{fontSize:30,lineHeight:1}}>{e}</span>
                <div>
                  <p style={{fontWeight:600,fontSize:15}}>{l}</p>
                  <p style={{color:"var(--mu)",fontSize:11,marginTop:2}}>{tip}</p>
                </div>
              </div>
              <div style={{textAlign:"right",flexShrink:0}}>
                <span style={{fontFamily:"var(--fd)",fontSize:38,color:c,lineHeight:1,display:"block"}}>{val}</span>
                <span style={{color:"var(--mu)",fontSize:11}}>{u}</span>
              </div>
            </div>
            <div style={{height:6,background:"#1e1e1e",borderRadius:3,overflow:"hidden",marginBottom:14}}>
              <div style={{height:"100%",width:`${pct}%`,background:c,borderRadius:3,transition:"width .4s"}}/>
            </div>
            <div style={{display:"flex",alignItems:"center",gap:12}}>
              <button onClick={()=>upd(k,Math.max(0,val-1))}
                style={{width:40,height:40,borderRadius:"50%",border:"1.5px solid var(--bd)",background:"transparent",color:"var(--wh)",fontSize:20,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}>−</button>
              <input type="range" min={0} max={m} value={val} onChange={e2=>upd(k,Number(e2.target.value))}/>
              <button onClick={()=>upd(k,Math.min(m,val+1))}
                style={{width:40,height:40,borderRadius:"50%",border:"1.5px solid rgba(200,255,0,.3)",background:"rgba(200,255,0,.06)",color:"var(--lime)",fontSize:20,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}>+</button>
            </div>
          </div>
        );
      })}
      <div style={{background:"#080800",border:"1px solid rgba(200,255,0,.1)",borderRadius:"var(--r)",padding:"18px 20px"}}>
        <p style={{fontFamily:"var(--fd)",fontSize:20,color:"var(--lime)",marginBottom:12,letterSpacing:"1px"}}>🍽 HOSTEL DIET HACKS</p>
        {["Eat dal-rice? Add salad. Fiber = fullness.","Avoid canteen fried food — once a week max.","Eat slowly. Brain takes 20 min to feel full.","Protein first: eggs, dal, curd every meal.","Cut sugary chai. Switch to black tea.","Never eat out of boredom — drink water first."].map((t,i)=>(
          <div key={i} style={{display:"flex",gap:10,marginBottom:8,alignItems:"flex-start"}}>
            <span style={{color:"var(--lime)",fontFamily:"var(--fm)",fontSize:11,flexShrink:0}}>0{i+1}</span>
            <p style={{color:"#888",fontSize:12,lineHeight:1.5}}>{t}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── PROGRESS ──────────────────────────────────────────────────────────────────
function ProgressTab({history,streak,skinChecked,tracker}){
  const sp=Math.round((skinChecked.length/SKIN.length)*100);
  const badges=[
    {n:"First Step",e:"👣",d:"Log first workout",ok:history.length>=1},
    {n:"Hydrated",e:"💧",d:"Hit 8 glasses",ok:tracker.water>=8},
    {n:"Skin God",e:"✨",d:"Full skincare done",ok:sp===100},
    {n:"3-Day Fire",e:"🔥",d:"3-day streak",ok:streak>=3},
    {n:"Week Warrior",e:"⚔️",d:"7-day streak",ok:streak>=7},
    {n:"Sleep King",e:"👑",d:"Log 8 hours sleep",ok:tracker.sleep>=8},
    {n:"Step Master",e:"🥾",d:"10k steps in a day",ok:tracker.steps>=10000},
    {n:"Glow Up",e:"🌟",d:"All habits complete",ok:tracker.water>=8&&tracker.sleep>=7&&sp>=80},
  ];
  return (
    <div className="sup" style={{display:"flex",flexDirection:"column",gap:14}}>
      <div>
        <h2 style={{fontFamily:"var(--fd)",fontSize:42,lineHeight:.95,letterSpacing:"2px"}}>YOUR<br/><span style={{color:"var(--pink)"}}>PROGRESS</span></h2>
        <p style={{color:"var(--mu)",fontSize:13,marginTop:6}}>Every rep, every habit. It counts. 🏆</p>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
        {[{l:"Workouts",v:history.length,s:"",c:"var(--lime)",e:"💪"},{l:"Day Streak",v:streak,s:" days",c:"var(--ora)",e:"🔥"},{l:"Skincare",v:sp,s:"%",c:"var(--cyan)",e:"✨"},{l:"Water Today",v:tracker.water,s:"gl",c:"#7B6AFF",e:"💧"}].map((s,i)=>(
          <div key={i} className="card" style={{padding:"18px 16px",position:"relative",overflow:"hidden"}}>
            <div style={{position:"absolute",top:-8,right:-8,fontSize:44,opacity:.06}}>{s.e}</div>
            <p style={{fontFamily:"var(--fd)",fontSize:44,lineHeight:1,color:s.c}}>{s.v}<span style={{fontSize:18}}>{s.s}</span></p>
            <p style={{color:"var(--mu)",fontSize:10,fontWeight:700,textTransform:"uppercase",letterSpacing:".8px",marginTop:6}}>{s.l}</p>
          </div>
        ))}
      </div>
      <div className="card">
        <p style={{fontFamily:"var(--fd)",fontSize:18,letterSpacing:"1px",color:"var(--mu)",marginBottom:14}}>RECENT SESSIONS</p>
        {history.length===0?(
          <p style={{color:"var(--mu)",fontSize:13}}>No workouts yet. Go crush one! 💪</p>
        ):history.slice(-5).reverse().map((h,i,arr)=>(
          <div key={i} style={{display:"flex",justifyContent:"space-between",alignItems:"center",paddingBottom:i<arr.length-1?10:0,marginBottom:i<arr.length-1?10:0,borderBottom:i<arr.length-1?"1px solid var(--bd)":"none"}}>
            <div style={{display:"flex",alignItems:"center",gap:10}}>
              <div style={{width:7,height:7,borderRadius:"50%",background:"var(--lime)"}}/>
              <span style={{fontSize:13,fontWeight:500}}>{h.name}</span>
            </div>
            <span style={{fontSize:11,color:"var(--mu)",fontFamily:"var(--fm)"}}>{h.date}</span>
          </div>
        ))}
      </div>
      <div className="card">
        <p style={{fontFamily:"var(--fd)",fontSize:18,letterSpacing:"1px",color:"var(--mu)",marginBottom:14}}>ACHIEVEMENT BADGES</p>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          {badges.map((b,i)=>(
            <div key={i} style={{background:b.ok?"rgba(200,255,0,.07)":"transparent",border:b.ok?"1.5px solid rgba(200,255,0,.2)":"1px solid #1a1a1a",borderRadius:"var(--rs)",padding:"14px 12px",opacity:b.ok?1:.25,transition:"all .3s"}}>
              <div style={{fontSize:28,marginBottom:6}}>{b.e}</div>
              <p style={{fontWeight:700,fontSize:12,color:b.ok?"var(--lime)":"var(--mu)"}}>{b.n}</p>
              <p style={{fontSize:10,color:"#444",marginTop:2}}>{b.d}</p>
            </div>
          ))}
        </div>
      </div>
      <div style={{background:"linear-gradient(135deg,#0d0010,#080008)",border:"1px solid rgba(255,51,102,.15)",borderRadius:"var(--r)",padding:"20px"}}>
        <p style={{fontFamily:"var(--fd)",fontSize:20,color:"var(--pink)",marginBottom:12,letterSpacing:"1px"}}>💡 LOOK COOL · FREE</p>
        {["Iron your clothes. Clean+ironed = 3x better looking.","Wear clothes that FIT. Doesn't need to be expensive.","Keep nails clean. Hands are noticed first.","Smell good. Soap + talc + clean clothes.","Haircut every 3–4 weeks. Changes everything.","Clean shoes daily. People check your feet."].map((t,i)=>(
          <div key={i} style={{display:"flex",gap:10,marginBottom:8,alignItems:"flex-start"}}>
            <span style={{color:"var(--pink)",fontFamily:"var(--fm)",fontSize:11,flexShrink:0}}>→</span>
            <p style={{color:"#888",fontSize:12,lineHeight:1.5}}>{t}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── ROOT ──────────────────────────────────────────────────────────────────────
const NAV=[{id:"home",l:"Home",ic:"🏠"},{id:"workout",l:"Workout",ic:"💪"},{id:"skin",l:"Skin",ic:"✨"},{id:"track",l:"Track",ic:"📊"},{id:"progress",l:"Progress",ic:"🏆"}];

export default function App(){
  const [tab,setTab]=useState("home");
  const [tracker,setTracker]=useState({water:0,steps:0,sleep:0,calories:0});
  const [skinChecked,setSkinChecked]=useState([]);
  const [history,setHistory]=useState([]);
  const [streak,setStreak]=useState(0);
  const [ready,setReady]=useState(false);

  useEffect(()=>{
    const style=document.createElement("style");
    style.innerHTML=CSS;
    document.head.appendChild(style);
    initCapacitor();
    (async()=>{
      const t=await Store.get("gu_tracker");
      if(t&&t.date===todayStr())setTracker(t);
      const sk=await Store.get("gu_skin");
      if(sk&&sk.date===todayStr())setSkinChecked(sk.checked||[]);
      const h=await Store.get("gu_hist");
      if(h)setHistory(h);
      const s=await Store.get("gu_streak");
      if(typeof s==="number")setStreak(s);
      setReady(true);
    })();
    return()=>document.head.removeChild(style);
  },[]);

  useEffect(()=>{if(ready)Store.set("gu_tracker",{...tracker,date:todayStr()});},[tracker,ready]);
  useEffect(()=>{if(ready)Store.set("gu_skin",{checked:skinChecked,date:todayStr()});},[skinChecked,ready]);
  useEffect(()=>{if(ready)Store.set("gu_hist",history);},[history,ready]);
  useEffect(()=>{if(ready)Store.set("gu_streak",streak);},[streak,ready]);

  const handleComplete=name=>{
    setHistory(h=>[...h,{name,date:new Date().toLocaleDateString()}]);
    setStreak(s=>s+1);
  };

  return (
    <div style={{background:"var(--bg)",minHeight:"100vh",maxWidth:480,margin:"0 auto",position:"relative"}}>
      <div style={{padding:"20px 16px 90px",minHeight:"100vh"}}>
        {tab==="home"&&<HomeTab tracker={tracker} streak={streak}/>}
        {tab==="workout"&&<WorkoutTab onComplete={handleComplete}/>}
        {tab==="skin"&&<SkinTab checked={skinChecked} setChecked={setSkinChecked}/>}
        {tab==="track"&&<TrackTab tracker={tracker} setTracker={setTracker}/>}
        {tab==="progress"&&<ProgressTab history={history} streak={streak} skinChecked={skinChecked} tracker={tracker}/>}
      </div>
      <div style={{position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",width:"100%",maxWidth:480,background:"rgba(6,6,6,.97)",backdropFilter:"blur(24px)",WebkitBackdropFilter:"blur(24px)",borderTop:"1px solid #161616",display:"flex",justifyContent:"space-around",padding:"8px 4px calc(14px + var(--sab))",zIndex:200}}>
        {NAV.map(n=>(
          <button key={n.id} className={`nb${tab===n.id?" on":""}`} onClick={()=>setTab(n.id)}>
            <span style={{fontSize:22,lineHeight:1}}>{n.ic}</span>
            <span>{n.l}</span>
            {tab===n.id&&<div style={{width:4,height:4,borderRadius:"50%",background:"var(--lime)"}}/>}
          </button>
        ))}
      </div>
    </div>
  );
}
